
  # Indie Music Zine

  This is a code bundle for Indie Music Zine. The original project is available at https://www.figma.com/design/JeTQNQY8TFKGs8GoNv92RY/Indie-Music-Zine.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  